//
//  BaseViewController.h
//  Xeterm
//
//  Created by Klwy on 16/11/2.
//  Copyright © 2016年 klwy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@end
